execute as @a[tag=!locator_range_set] run attribute @s minecraft:waypoint_transmit_range base set 128
tag @a[tag=!locator_range_set] add locator_range_set
schedule function locator:check 1s replace