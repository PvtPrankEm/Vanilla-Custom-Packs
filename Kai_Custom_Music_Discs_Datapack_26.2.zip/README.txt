KAI'S 12 CUSTOM MUSIC DISCS — MINECRAFT JAVA 26.2

FILES
- Kai_Custom_Music_Discs_Datapack_26.2.zip
- Kai_Custom_Music_Discs_Resourcepack_26.2.zip

INSTALL IN AMP
1. Stop the Minecraft instance and make a backup.
2. Put the datapack ZIP directly in:
   <world folder>/datapacks/
   Do not unzip it.
3. Host the resource-pack ZIP using your normal server resource-pack method.
   If you already have a server resource pack, merge this pack's files into it
   instead of configuring a second server pack.
4. Restart the server. A full restart is recommended when adding jukebox songs.
5. Join and let Minecraft download/reload the resource pack.

GET THE DISCS
As a player with permission:
  /function kai_discs:give/all

From the AMP console, replace Kai with the exact player name:
  execute as Kai run function kai_discs:give/all

Individual discs:
  /function kai_discs:give/disc_01
  through
  /function kai_discs:give/disc_12

REPLACING THE PLACEHOLDER AUDIO
1. Extract the resource-pack ZIP.
2. Replace the matching OGG Vorbis file:
   assets/kai_discs/sounds/music_disc/disc_01.ogg
   through
   assets/kai_discs/sounds/music_disc/disc_12.ogg
3. In the datapack, change length_in_seconds in the matching file:
   data/kai_discs/jukebox_song/disc_01.json
   through
   data/kai_discs/jukebox_song/disc_12.json
4. Re-zip each pack with pack.mcmeta at the ZIP root.
5. Restart the server and update the server resource-pack download/SHA-1.

IMPORTANT
- Audio must be OGG Vorbis, not MP3 renamed to .ogg.
- These discs are not craftable and do not appear in the creative inventory.
- Disc 01: My Chemical Romance - Helena (3:30.721)
- Disc 02: Brandon Jamar Scott - Mario Don't Save Her (1:25.658)
- Disc 03: Bloodhound Gang - A Lap Dance Is So Much Better When the Stripper Is Crying (5:37.582)
- Disc 04: Ben Folds feat. William Shatner - Rockin' the Suburbs (Over the Hedge Version) (4:56.101)
- Disc 05: Ben Folds - Heist (3:01.162)
- Disc 06: Fall Out Boy - Dance, Dance (2:59.165)
- Disc 07: My Chemical Romance - Teenagers (2:45.017)
- Disc 08: My Chemical Romance - Welcome to the Black Parade (5:11.263)
- Disc 09: Evanescence - Afterlife (4:10.079)
- Disc 10: Bo Burnham - Welcome to the Internet (4:40.590)
- Disc 11: The Chalkeaters feat. Natalia Natchan - DOOM Crossing: Eternal Horizons (1:34.691)
- Disc 12: Angry Children & mewtenDoo - Blend W (1:32.833)
- Every audio file is mono OGG Vorbis so jukebox proximity falloff works correctly.
- Every texture uses the same flat oval, broad-color-band 16x16 framework.
- Namespace: kai_discs
- Datapack format: 107.1
- Resource-pack format: 88.0
