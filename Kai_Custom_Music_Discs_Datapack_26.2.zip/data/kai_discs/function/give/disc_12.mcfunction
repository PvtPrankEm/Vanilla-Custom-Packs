give @s minecraft:music_disc_13[minecraft:jukebox_playable="kai_discs:disc_12",minecraft:item_model="kai_discs:disc_12"] 1
