give @s minecraft:music_disc_13[minecraft:jukebox_playable="kai_discs:disc_06",minecraft:item_model="kai_discs:disc_06"] 1
